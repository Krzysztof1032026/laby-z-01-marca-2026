import math
import matplotlib.pyplot as plot

#generator liczb U(0,1)
A = 16807                   #ustawiam parametry
B = 0
C = 2147483647

aktualne_ziarno = 1         #zmienna globalna przechowujaca stan obecny-ziarno

def ustaw_ziarno(ziarno):

    global aktualne_ziarno
    if ziarno is not None:
        aktualne_ziarno = ziarno
    else:
        aktualne_ziarno = 12345     #jesli nie ma ziarna uzyjemy dowolnej liczby np.tej


def GenU():

    global aktualne_ziarno
    aktualne_ziarno = (A * aktualne_ziarno + B) % C             #ze wzoru: x_n+1 = (a * x_n + b) mod c
    return aktualne_ziarno / C                                  #dzielenie przez C, aby otrzymac ulamek z przedzialu (0, 1)

def generuj_poissona(lam, ilosc_liczb):                         #generatory rozkladow
    dane = []
    q = math.exp(-lam)

    for i in range(ilosc_liczb):
        X = -1
        S = 1.0
        while S > q:
            U = GenU()
            S = S * U
            X = X + 1
        dane.append(X)
    return dane

def generuj_normalny(mi, sigma, ilosc_liczb):
    dane = []

    for i in range(ilosc_liczb):
        U1 = GenU()
        U2 = GenU()

        #metoda Boxa-Mullera dla standardowego rozkładu N(0,1)
        Z0 = math.sqrt(-2.0 * math.log(U1)) * math.cos(2.0 * math.pi * U2)

        #przeksztalcenie do zadanego N(mi, sigma)
        X = mi + sigma * Z0
        dane.append(X)
    return dane

#program glowny
ILOSC = 10000           #parametry wywolan

ustaw_ziarno(42)        #wlaczenie gennerownia z ziarnem (powtarzalne wyniki)

dane_poisson = generuj_poissona(lam=5, ilosc_liczb=ILOSC)       #zbieranie danych do tablic
dane_normalny = generuj_normalny(mi=10, sigma=2, ilosc_liczb=ILOSC)

#rysowanie wykresow
plot.figure(1)                  #wykres1 rozklad poissona
plot.title("Rozkład Poissona (lambda=5)")
plot.hist(dane_poisson, bins=15, edgecolor='black')
plot.xlabel("Wartość")
plot.ylabel("Ilość wystąpień")

plot.figure(2)                  #wykres2 rozklad normalny
plot.title("Rozkład Normalny (mi=10, sigma=2)")
plot.hist(dane_normalny, bins=100, edgecolor='black', color='green')
plot.xlabel("Wartość")
plot.ylabel("Ilość wystąpień")

plot.show()                    #wyswietl oba wykresy
