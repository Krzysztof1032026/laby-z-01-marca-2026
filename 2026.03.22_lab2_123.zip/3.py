import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# --- PARAMETRY SYMULACJI (Zadanie 2) ---
S = 10  # Liczba kanałów [cite: 78]
LAMBDA = 2.5  # Parametr natężenia ruchu (Poisson) [cite: 79]
N = 60  # Średnia długość rozmowy (Gauss) [cite: 81]
SIGMA = 15  # Odchylenie standardowe (Gauss) [cite: 82]
MIN_LEN = 10  # Minimalna długość rozmowy [cite: 83]
MAX_LEN = 300  # Maksymalna długość rozmowy [cite: 84]
QUEUE_LIMIT = 5  # Długość kolejki [cite: 85]
SIM_TIME = 300  # Czas symulacji w sekundach [cite: 86]

# --- KROKI IMPLEMENTACYJNE ---

# 1. Wygenerowanie listy przybyć (inter-arrival times) [cite: 100]
inter_arrival_times = []
current_sum = 0
while current_sum < SIM_TIME:
    # W procesie Poissona czas między zdarzeniami ma rozkład wykładniczy
    t = np.random.exponential(1.0 / LAMBDA)
    inter_arrival_times.append(t)
    current_sum += t

# 2. Wygenerowanie długości rozmów (Rozkład Gaussa) [cite: 101]
call_durations = []
for _ in range(len(inter_arrival_times)):
    dur = np.random.normal(N, SIGMA)
    dur = np.clip(dur, MIN_LEN, MAX_LEN)  # Ograniczenie do Min i Maks [cite: 83, 84]
    call_durations.append(dur)

arrivals = list(zip(inter_arrival_times, call_durations))

# Inicjalizacja struktur danych
channels = [0.0] * S  # Czas pozostały do końca rozmowy w każdym kanale [cite: 88]
queue = []  # Kolejka zgłoszeń oczekujących [cite: 85]
history = []  # Dane do statystyk i wykresów [cite: 90]
arrival_ptr = 0
handled_total = 0

# 3. Pętla symulacji (1 krok = 1 sekunda) [cite: 102]
print(f"Rozpoczynanie symulacji: {S} kanałów, czas {SIM_TIME}s...")

for t_step in range(SIM_TIME):
    # a. Pobranie zgłoszeń przybywających w bieżącej sekundzie [cite: 103]
    current_sec_calls = []
    time_in_sec = 0
    while arrival_ptr < len(arrivals):
        inter_t, dur = arrivals[arrival_ptr]
        if time_in_sec + inter_t <= 1.0:
            current_sec_calls.append(dur)
            time_in_sec += inter_t
            arrival_ptr += 1
        else:
            # Przesunięcie pozostałego czasu na kolejną sekundę
            arrivals[arrival_ptr] = (inter_t - (1.0 - time_in_sec), dur)
            break

    # Aktualizacja kanałów - upływ sekundy [cite: 108]
    for i in range(S):
        if channels[i] > 0:
            channels[i] = max(0, channels[i] - 1)

    # b. Umieszczenie nowych zgłoszeń w kanałach lub kolejce [cite: 104]
    for call_dur in current_sec_calls:
        placed = False
        for i in range(S):
            if channels[i] == 0:
                channels[i] = call_dur
                handled_total += 1
                placed = True
                break

        if not placed:
            if len(queue) < QUEUE_LIMIT:
                queue.append(call_dur)
            # Jeśli brak miejsca w kolejce, zgłoszenie jest tracone (model blokowy)

    # Przesunięcie z kolejki do zwolnionych kanałów
    for i in range(S):
        if channels[i] == 0 and len(queue) > 0:
            channels[i] = queue.pop(0)
            handled_total += 1

    # c. Obliczanie parametrów rho, Q, W [cite: 105]
    busy_count = sum(1 for c in channels if c > 0)
    rho = busy_count / S  # Intensywność ruchu [cite: 93]
    Q_val = len(queue)  # Średnia długość kolejki [cite: 94]
    W_val = Q_val / LAMBDA  # Średni czas oczekiwania (wg wzoru Little'a) [cite: 96]

    history.append({'t': t_step, 'rho': rho, 'Q': Q_val, 'W': W_val})

# --- WYNIKI I WYKRESY ---

# Zapis do pliku [cite: 92, 97, 98]
df = pd.DataFrame(history)
df.to_csv("parametry_symulacji.txt", sep='\t', index=False)

# Generowanie wykresów
plt.figure(figsize=(10, 12))

plt.subplot(3, 1, 1)
plt.plot(df['t'], df['rho'], label='Intensywność (rho)', color='b')
plt.title('Intensywność ruchu w czasie')
plt.ylabel('rho')
plt.grid(True)

plt.subplot(3, 1, 2)
plt.plot(df['t'], df['Q'], label='Długość kolejki (Q)', color='r')
plt.title('Średnia długość kolejki')
plt.ylabel('Q')
plt.grid(True)

plt.subplot(3, 1, 3)
plt.plot(df['t'], df['W'], label='Czas oczekiwania (W)', color='g')
plt.title('Średni czas oczekiwania')
plt.xlabel('Czas symulacji [s]')
plt.ylabel('W')
plt.grid(True)

plt.tight_layout()
plt.show()

print(f"Symulacja skończona. Obsłużono {handled_total} połączeń.")