import math
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

#FUNKCJE LOGICZNE (ZADANIE 1)

def calculate_m_m_s_s_basic(l_o, l_h, mu, S):
    """Obl. dla modelu podstawowego."""
    l_total = l_o + l_h
    denominator = sum([(l_total ** i) / (math.factorial(i) * (mu ** i)) for i in range(int(S) + 1)])
    p0 = 1 / denominator
    blocking_prob = ((l_total ** S) / (math.factorial(S) * (mu ** S))) * p0
    return blocking_prob

def calculate_m_m_s_s_reservation(l_o, l_h, mu, S, Sc):
    """Obl. dla modelu z rezerwacją."""
    S, Sc = int(S), int(Sc)
    term1 = sum([(l_o + l_h) ** i / (math.factorial(i) * mu ** i) for i in range(Sc + 1)])
    term2 = sum([((l_o + l_h) ** Sc * l_h ** (i - Sc)) / (math.factorial(i) * mu ** i) for i in range(Sc + 1, S + 1)])
    p0 = 1 / (term1 + term2)

    probs = []
    for i in range(S + 1):
        if i <= Sc:
            p_i = ((l_o + l_h) ** i / (math.factorial(i) * mu ** i)) * p0
        else:
            p_i = ((l_o + l_h) ** Sc * l_h ** (i - Sc) / (math.factorial(i) * mu ** i)) * p0
        probs.append(p_i)

    bo = sum(probs[Sc:]) # Prawdopodobieństwo blokady nowych zgłoszeń
    bh = probs[S]        # Prawdopodobieństwo blokady handoverów
    return bo, bh

#INTERFEJS GRAFICZNY

class TheoreticalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Kalkulator Modelu M/M/S/S - Teoria")
        self.root.geometry("1000x800")

        self.setup_ui()
        self.update_plot(0, 0, 0)

    def setup_ui(self):
        # Panel boczny z parametrami
        sidebar = ttk.Frame(self.root, padding="10")
        sidebar.pack(side="left", fill="y")

        ttk.Label(sidebar, text="Parametry Systemu", font=('Arial', 12, 'bold')).pack(pady=10)

        self.params = {
            'λo (Nowe)': tk.DoubleVar(value=4.0),
            'λH (Handover)': tk.DoubleVar(value=1.0),
            'μ (Obsługa)': tk.DoubleVar(value=1.0),
            'S (Kanały)': tk.IntVar(value=10),
            'Sc (Próg)': tk.IntVar(value=8)
        }

        for text, var in self.params.items():
            ttk.Label(sidebar, text=text).pack(anchor="w")
            ttk.Entry(sidebar, textvariable=var).pack(fill="x", pady=2)

        ttk.Button(sidebar, text="Oblicz", command=self.on_calculate).pack(pady=20, fill="x")

        # Wyniki tekstowe
        self.res_label = ttk.Label(sidebar, text="", font=('Arial', 10), justify="left")
        self.res_label.pack(pady=10, anchor="w")

        # Panel wykresu
        self.plot_frame = ttk.Frame(self.root)
        self.plot_frame.pack(side="right", expand=True, fill="both")

    def on_calculate(self):
        try:
            l_o = self.params['λo (Nowe)'].get()
            l_h = self.params['λH (Handover)'].get()
            mu = self.params['μ (Obsługa)'].get()
            S = self.params['S (Kanały)'].get()
            Sc = self.params['Sc (Próg)'].get()

            if Sc > S:
                messagebox.showerror("Błąd", "Sc nie może być większe niż S!")
                return

            b_basic = calculate_m_m_s_s_basic(l_o, l_h, mu, S)
            bo_res, bh_res = calculate_m_m_s_s_reservation(l_o, l_h, mu, S, Sc)

            res_text = (f"MODEL PODSTAWOWY:\nBo = BH: {b_basic:.4f}\n\n"
                        f"REZERWACJA (Sc={Sc}):\nBo: {bo_res:.4f}\nBH: {bh_res:.4f}")
            self.res_label.config(text=res_text)

            self.update_plot(b_basic, bo_res, bh_res)

        except Exception as e:
            messagebox.showerror("Błąd", f"Niepoprawne dane: {e}")

    def update_plot(self, b_basic, bo_res, bh_res):
        for widget in self.plot_frame.winfo_children():
            widget.destroy()

        fig, ax = plt.subplots(figsize=(6, 5))
        labels = ['Model Podst. (Bo/BH)', 'Rezerwacja (Bo)', 'Rezerwacja (BH)']
        values = [b_basic, bo_res, bh_res]
        colors = ['gray', 'blue', 'red']

        ax.bar(labels, values, color=colors)
        ax.set_ylabel('Prawdopodobieństwo Blokady')
        ax.set_title('Porównanie Prawdopodobieństwa Blokowania [z1]')
        ax.set_ylim(0, max(values + [0.1]) * 1.2)

        canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill="both")

if __name__ == "__main__":
    root = tk.Tk()
    app = TheoreticalApp(root)
    root.mainloop()
